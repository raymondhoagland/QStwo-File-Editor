import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.BufferedWriter;
import java.util.Scanner;
import java.io.FileWriter;

public class ScriptEditor2013_2{
	static public class Option{ //base class with majority of methods
		String startDate = null; //variables for methods
		String endDate = null;
		String beginningAccount = null;
		String endingAccount = null;
		String beginningPeriod = null;
		File newfile = null;
		Scanner scanner;
		Option(){
		}
		String getLine() { // get the next line from console and return it
			scanner = new Scanner(System.in);
			String out =  scanner.nextLine();
			return out;
		}
		static boolean isValidFileName(File file){ //check if this file name has been used already
			if(file==null)
				return true;
			try{
				if(file.createNewFile()==false){
					return false;
				}
			}
			catch(Exception e){
				return false;
			}
			return true;
		}
		File promptForFileName(){ //ask for the name of the file the user wishes to create
			System.out.println("What would you like to name the new script file?");
			String filename = getLine();
			File newfile = new File("C:/Program Files/IBM/Client Access/Emulator/Private/"+ filename +".mac"); //destination
			while(!isValidFileName(newfile)){
				System.out.print("File exists.  Do you want to overwrite it? (Y/N): "); //prompt for overwrite
				String check= getLine();
				if(check.equals("Y")||check.equals("y"))break; //overwrites file  
				else if (check.equals("N")||check.equals("n")){
					System.out.print("Please enter a different name for the script file: "); //prompt for different name
					filename = getLine();
					newfile = new File("C:/Program Files/IBM/Client Access/Emulator/Private/"+ filename +".mac"); //destination
				}
				else{
					System.out.print("Invalid response.  "); //not answering yes or no is invalid
				}
			}
			return newfile;
		}
		boolean isValidDate(int status, String date, String prev){ //check if date is legitimate based on number of days in each month, number of months in year, after or equal to any previously entered date
			if(date.length()<6||date.length()>6){ //check format
				System.out.println("Input was not six digits.");
				return false;
			}
			int year = 0;
			int month =0;
			int day =0;
			if(status==0){
				try{
				month=Integer.parseInt(date.substring(0, 2)); //MM
				day=Integer.parseInt(date.substring(2, 4));   //DD
				year=Integer.parseInt(date.substring(4, 6));  //YY
				}
				catch(Exception e){ //input is not a number
					System.out.println("The input was not a valid number.");
					return false;
				}
				//return true;
			}
			else{ //secondary format YYMMDD
				try{
				year=Integer.parseInt(date.substring(0, 2));
				month=Integer.parseInt(date.substring(2, 4));
				day=Integer.parseInt(date.substring(4, 6));
				}
				catch(Exception e){
					System.out.println("The input was not a valid number.");
					return false;
				}
			}
			if(prev!=null){
				int month2 =Integer.parseInt(prev.substring(0, 2));
				int day2=Integer.parseInt(prev.substring(2, 4));
				int year2=Integer.parseInt(prev.substring(4, 6));
				if(year2>year){
					System.out.println("First date entered occurred after the second date."); //based on year, this date is too early
					return false;
				}
				else if(year2==year&&month2>month){
					System.out.println("First date entered occurred after the second date."); //year passes but month fails
					return false;
				}
				else if(year2==year&&month2==month&&day2>day){
					System.out.println("First date entered occurred after the second date."); //year & month passes but day fails
					return false;
				}
			}
			if(month>12){ //only twelve months in year
				System.out.println("The input was not a valid date. (Month greater than twelve)");
				return false;
			}
			if(month==0){ //no zero month
				System.out.println("The input was not a valid date. (Month equal to zero)");
				return false;
			}
			if(month<=12&&month!=0){ 
				if(month==2){ //assuming leap year maximum
					if(day<=29&&day!=0){		
						return true;
					}
					System.out.println("The input was not a valid date.  (Given day not valid for given month.");
					return false;
				}
				if(month==4||month==6||month==9||month==11){ //months with 30 days
					if(day<=30&&day!=0){
						return true;
					}
					System.out.println("The input was not a valid date. (Given day not valid for given month.");
					return false;
				}
				else{ //mmonths with 31 days
					if(day<=31&&day!=0)
						return true;
					System.out.println("The input was not a valid date. (Given day not valid for given month.");
					return false;
				}
			}	
			return false;
		}
		boolean isValidAccount(String account, String prev){
			try{
				int count = Integer.parseInt(account);
				if(count==0){
					System.out.println("Zero is not a valid input."); 
					return false;
				}
			}
			catch(Exception e){ ///input not a number
				System.out.println("The input was not a valid number");
				return false;
			}
			if(prev!=null){
				if(Integer.parseInt(prev)<=Integer.parseInt(account)){ //first account is smaller than second
					if(account.length()!=3){
						System.out.println("Input was not three digits."); //input too short/long
						return false;
					}
					return true;
				}
				System.out.println("First account entered was larger than the second account.");
				return false;
			}
			if(account.length()!=3){
				System.out.println("Input was not three digits.");
				return false;
			}
			return true;
		}
		boolean isValidPeriod(String period){ //same as others but checking period
			try{
					if(Integer.parseInt(period)<=12&&period.length()==2&&Integer.parseInt(period)!=0)
						return true;
					if(Integer.parseInt(period)>12){
						System.out.println("Input was larger than twelve.");
						return false;
					}
					if(period.length()!=2){
						System.out.println("Input was not two digits.");
						return false;
					}
					if(Integer.parseInt(period)==0){
						System.out.println("Zero is not valid input.");
						return false;
					}
			}
			catch(Exception e){
				System.out.println("Input was not a number.");
				return false;
			}
			return true;
		}
		String getDate(int status){ //prompt for and set date
			if(status == 0){
				System.out.println("What beginning date would you like to use?");
				startDate = this.getLine();
				while(!isValidDate(0, startDate, null)){ //0 indicates MMDDYY and null indicates lack of previous entry
						System.out.print("Please enter a valid date: ");
						startDate=getLine();
				}
				return startDate;
			}
			else{
				System.out.println("What ending date would you like to use?");
				endDate = this.getLine();
				while(!isValidDate(0, endDate, startDate)){ //0 indicates MMDDYY previous is now startDate
						System.out.print("Please enter a valid date: ");
						endDate=getLine();
				}
				return endDate;
			}
		}
		String getAccount(int status){ //prompt for and set account
			if(status == 0){
				System.out.println("What beginning account (3 digits) would you like to use?");
				beginningAccount = getLine();
				while(!isValidAccount(beginningAccount, null)){ //no previous entry
						System.out.print("Please enter a valid account: ");
						beginningAccount=getLine();
				}
				return beginningAccount;
			}
			else{
				System.out.println("What ending account (3 digits) would you like to use?");
				endingAccount = getLine();
				while(!isValidAccount(endingAccount, beginningAccount)){ //checking against beginningAccount
						System.out.print("Please enter a valid account: ");
						endingAccount=getLine();
				}
				return endingAccount;
			}
		}
		String getPeriod(){ //prompt for and set period
			System.out.println("What period (01-12 is valid) would you like to use?");
			beginningPeriod = getLine();
				while(!isValidPeriod(beginningPeriod)){
					System.out.print("Please enter a valid period: ");
					beginningPeriod=getLine();
				}
				return beginningPeriod;
		}
	}
	static public class Option1 extends Option{
		String startDate = null;
		String endDate = null;
		String beginningAccount=null;
		String endingAccount=null;	
		File newfile = null;
		Option1(){
			
		}
		String getLine(){
			return super.getLine();
		}
		File promptForFileName(){
			newfile = super.promptForFileName();
			return newfile;
		}
		boolean isValidDate(int status, String date, String prev){
			return super.isValidDate(status, date, prev);
		}
		boolean isValidAccount(String account, String prev){
			return super.isValidAccount(account, prev);
		}
		String getDate(int status){ //determine whether beginning or ending date
			if(status == 0 ){
				startDate = super.getDate(status);
				return startDate;
			}
			if(status == 1){
				endDate = super.getDate(status);
				return endDate;
			}
			return null;
		}
		String getAccount(int status){ //determine whether beginning or ending account
			if(status == 0 ){
				beginningAccount = super.getAccount(status);
				return beginningAccount;
			}
			if(status == 1){
				endingAccount = super.getAccount(status);
				return endingAccount;
			}
			return null;
		}
		void writeToFile(File newfile) throws IOException{ //create the new file
			int switcherSixes = 1; //balancer for sixes
			int switcherThrees = 1; //balancer for threes
			FileWriter fstream = new FileWriter(newfile);
			BufferedWriter out = new BufferedWriter(fstream);
			try {
				File reference = new File("C:/Master Scripts/GL_Activity.mac"); //reference script
				Scanner scanner = new Scanner(reference);
				String newLine = "";
				while (scanner.hasNextLine()) {
					newLine = scanner.nextLine(); 
					if (newLine.contains("******")) { 
						if (switcherSixes > 0) { //determine which input to substitute
							newLine = newLine.replace("******", startDate); 
						} else {
							newLine = newLine.replace("******", endDate);
						}
						switcherSixes = -switcherSixes; //flip balancer
					} else if (newLine.contains("\"***\"")) { //determine which input to substitute
						if (switcherThrees > 0) {
							newLine = newLine.replace("***", beginningAccount); 
						} else { 
							newLine = newLine.replace("***", endingAccount);
						}
						switcherThrees = -switcherThrees; //flip balancer
					}
					out.write(newLine);
					out.newLine();
				}
				scanner.close(); //close scanner to prevent leaking
				System.out.println("File created successfully.");
			} catch (FileNotFoundException e) {
				System.out.println("Invalid reference given."); //reference file does not exist
				return; 
			} finally {
				out.close(); 
			}
		}
		void execute() throws IOException{ //run all methods and complete 
			promptForFileName();
			getDate(0);
			getDate(1);
			getAccount(0);
			getAccount(1);
			writeToFile(newfile);
		}
	}
	static public class Option2 extends Option{ 
		String startDate = null;
		String endDate = null;
		File newfile = null;
		Option2(){
		}
		String getLine(){
			return super.getLine();
		}
		File promptForFileName(){
			newfile = super.promptForFileName();
			return newfile;
		}
		boolean isValidDate(int status, String date, String prev){
			return super.isValidDate(status, date, prev);
		}
		String getDate(int status){ //same as Option1 getDate
			if(status == 0 ){
				startDate = super.getDate(status);
				return startDate;
			}
			if(status == 1){
				endDate = super.getDate(status);
				return endDate;
			}
			return null;
		}
		void writeToFile() throws IOException{ //create the new file
			int switcherSixes = 1; //balancer for sixes
			FileWriter fstream = new FileWriter(newfile);
			BufferedWriter out = new BufferedWriter(fstream);
			try {
				File file = new File("C:/Master Scripts/AP_Posting.mac"); //reference script
				Scanner scanner = new Scanner(file);
				String newLine = "";
				while (scanner.hasNextLine()) {
					newLine = scanner.nextLine(); 
						if (newLine.contains("\"")) {
							if(newLine.indexOf("\"")==(newLine.lastIndexOf("\"")-7)){ //length must be six in between the quotes
								String check = (newLine.substring(newLine.indexOf("\"")+1, newLine.lastIndexOf("\"")));
								boolean jack = false;
								for(int i=0; i<check.length(); i++){
									if(!Character.isDigit(check.charAt(i))){ //make sure that each character in between quotes is a digit
											jack=true;
											break;
									}
								}
								if(!jack){ //if passes replace
									if (switcherSixes > 0) { 
										newLine=newLine.replace(check, startDate); 
									}
									else { 
										newLine=newLine.replace(check, endDate);
									}
									switcherSixes = -switcherSixes;
								}
							}
						}
						out.write(newLine); 
						out.newLine();
				}
				scanner.close(); //close the scanner to prevent leaking
				System.out.println("File created successfully.");
			}
			catch (FileNotFoundException e) {
				System.out.println("Invalid reference given."); //reference file does not exist
				return; 
			}
			finally{
				out.close();
			}
		}
		void execute() throws IOException{ //run all methods and finish 
			promptForFileName();
			getDate(0);
			getDate(1);
			writeToFile();
		}
	}
	static public class Option3 extends Option{
		String beginningPeriod = null;
		File newfile = null;
		Option3(){
		}
		String getLine(){
			return super.getLine();
		}
		File promptForFileName(){
			newfile = super.promptForFileName();
			return newfile;
		}
		boolean isValidPeriod(String period){
			return super.isValidPeriod(period);
		}
		String getPeriod(){
			beginningPeriod = super.getPeriod();
			return beginningPeriod;
		}
		void writeToFile() throws IOException{
			FileWriter fstream = new FileWriter(newfile);
			BufferedWriter out = new BufferedWriter(fstream);
			try {
				File file = new File("C:/Master Scripts/Trial_Balance.mac"); //reference script 
				Scanner scanner = new Scanner(file);
				String newLine = "";
				while (scanner.hasNextLine()) {
					newLine = scanner.nextLine();
					if (newLine.contains("\"**\"")) { //look for "**"
							newLine = newLine.replace("**", beginningPeriod); //replace it				
						}
					out.write(newLine); 
					out.newLine();
				}
				scanner.close();
				System.out.println("File created successfully.");
			} catch (FileNotFoundException e) {
				System.out.println("Invalid reference given."); //reference file does not exist
				return; 
			} finally {
				out.close(); 
			}
		}
		void execute() throws IOException{ //run methods and finish
			promptForFileName();
			getPeriod();
			writeToFile();
		}
	}
	static public class Option4 extends Option{
		String endDate = null;
		File newfile = null;
		Option4(){
		}
		String getLine(){
			return super.getLine();
		}
		File promptForFileName(){
			newfile = super.promptForFileName();
			return newfile;
		}
		boolean isValidDate(String date){
			return super.isValidDate(1, date, null);
		}
		String getDate(){ //getDate now has different format and requires different prompts
			System.out.println("What is the last day of the period (YYMMDD) that you would like to use?");
			String endDate = getLine();
			while(!isValidDate(endDate)){
				System.out.print("Please enter a valid date(YYMMDD): ");
				endDate=getLine();
			}
			return endDate;
		}
		void writeToFile() throws IOException{
			FileWriter fstream = new FileWriter(newfile);
			BufferedWriter out = new BufferedWriter(fstream);
			try {
				File file = new File("C:/Master Scripts/AP_to_GL_WrkQry.mac"); //reference file
				Scanner scanner = new Scanner(file);
				String newLine = "";
				while (scanner.hasNextLine()) {
					newLine = scanner.nextLine(); 
						if (newLine.contains("\"*******\"")) { //look for key
									newLine=newLine.replace("*******", "1"+endDate); //replace and add 1 to front on user input
						}			
						out.write(newLine); 
						out.newLine();
				
				}	
				System.out.println("File created successfully.");
				scanner.close();
			}
			catch (FileNotFoundException e) {
				System.out.println("Invalid reference given."); //reference file does not exist
				return; 
			}
			finally{
				out.close();
			}
		}
		void execute() throws IOException{ //run all methods and finish
			promptForFileName();
			getDate();
			writeToFile();
		}
	}
	static public class Option5 extends Option{ 
		String startDate = null;
		String endDate = null;
		String warehouseNum = null;
		File newfile = null;
		Option5(){
		}
		String getLine(){
			return super.getLine();
		}
		File promptForFileName(){
			newfile = super.promptForFileName();
			return newfile;
		}
		boolean isValidDate(String date, String prev){
			return super.isValidDate(1, date, prev);
		}
		boolean isValidWarehouse(String warehouseNum){
			int warehouseNumx = Integer.parseInt(warehouseNum);
			return (warehouseNumx>=0&&warehouseNumx<=6);
		}
		String getDate(int status){ //same as Option1 getDate
			if(status == 0 ){
				System.out.println("What is the first day of the period (YYMMDD) that you would like to use?");
				String startDate = getLine();
				while(!isValidDate(startDate, null)){
					System.out.print("Please enter a valid date(YYMMDD): ");
					startDate=getLine();
				}
				return startDate;
			}
			if(status == 1){
				System.out.println("What is the last day of the period (YYMMDD) that you would like to use?");
				String endDate = getLine();
				while(!isValidDate(endDate, startDate)){
					System.out.print("Please enter a valid date(YYMMDD): ");
					endDate=getLine();
				}
				return endDate;
			}
			return null;
		}
		String getWarehouse(){
			System.out.println("Which warehouse is this for? (Enter 0-6)");
			String warehouseNum =  this.getLine();
			while(!isValidWarehouse(warehouseNum)){
				System.out.print("Please enter a valid warehouse(0-6): ");
				warehouseNum=getLine();
			}
			return warehouseNum;
		}
		void writeToFile() throws IOException{ //create the new file
			int switcherSixes = 1; //balancer for sixes
			FileWriter fstream = new FileWriter(newfile);
			BufferedWriter out = new BufferedWriter(fstream);
			try {
				File file = new File("C:/Master Scripts/ARCASH12rev1.mac"); 
				Scanner scanner = new Scanner(file);
				String newLine = "";
				while (scanner.hasNextLine()) {
					newLine = scanner.nextLine(); 
						if(newLine.contains("z"))
							newLine= newLine.replace("z", warehouseNum);
						else if (newLine.contains("yymmdd")) {
									if (switcherSixes > 0) { 
										newLine=newLine.replace("yymmdd", startDate); 
									}
									else { 
										newLine=newLine.replace("yymmdd", endDate);
									}
									switcherSixes = -switcherSixes;
								}
						out.write(newLine); 
						out.newLine();
				}
				scanner.close(); //close the scanner to prevent leaking
				System.out.println("File created successfully.");
			}
			catch (FileNotFoundException e) {
				System.out.println("Invalid reference given."); //reference file does not exist
				return; 
			}
			finally{
				out.close();
			}
		}
		void execute() throws IOException{ //run all methods and finish 
			promptForFileName();
			startDate= getDate(0);
			endDate = getDate(1);
			warehouseNum = getWarehouse();
			writeToFile();
		}
	}
	static public class Option6 extends Option{ 
		String startDate = null;
		String endDate = null;
		File newfile = null;
		Option6(){
		}
		String getLine(){
			return super.getLine();
		}
		File promptForFileName(){
			newfile = super.promptForFileName();
			return newfile;
		}
		boolean isValidDate(String date, String prev){
			return super.isValidDate(1, date, prev);
		}
		String getDate(int status){ //same as Option1 getDate
			if(status == 0 ){
				System.out.println("What is the first day of the period (YYMMDD) that you would like to use?");
				String startDate = getLine();
				while(!isValidDate(startDate, null)){
					System.out.print("Please enter a valid date(YYMMDD): ");
					startDate=getLine();
				}
				return startDate;
			}
			if(status == 1){
				System.out.println("What is the last day of the period (YYMMDD) that you would like to use?");
				String endDate = getLine();
				while(!isValidDate(endDate, startDate)){
					System.out.print("Please enter a valid date(YYMMDD): ");
					endDate=getLine();
				}
				return endDate;
			}
			return null;
		}
		void writeToFile() throws IOException{ //create the new file
			int switcherSixes = 1; //balancer for sixes
			FileWriter fstream = new FileWriter(newfile);
			BufferedWriter out = new BufferedWriter(fstream);
			try {
				File file = new File("C:/Master Scripts/CCINV.mac"); 
				Scanner scanner = new Scanner(file);
				String newLine = "";
				while (scanner.hasNextLine()) {
					newLine = scanner.nextLine(); 
						if (newLine.contains("yymmdd")) {
									if (switcherSixes > 0) { 
										newLine=newLine.replace("yymmdd", startDate); 
									}
									else { 
										newLine=newLine.replace("yymmdd", endDate);
									}
									switcherSixes = -switcherSixes;
								}
						out.write(newLine); 
						out.newLine();
				}
				scanner.close(); //close the scanner to prevent leaking
				System.out.println("File created successfully.");
			}
			catch (FileNotFoundException e) {
				System.out.println("Invalid reference given."); //reference file does not exist
				return; 
			}
			finally{
				out.close();
			}
		}
		void execute() throws IOException{ //run all methods and finish 
			promptForFileName();
			startDate= getDate(0);
			endDate = getDate(1);
			writeToFile();
		}
	}
	static public class Option7 extends Option{ 
		String startDate = null;
		String endDate = null;
		File newfile = null;
		Option7(){
		}
		String getLine(){
			return super.getLine();
		}
		File promptForFileName(){
			newfile = super.promptForFileName();
			return newfile;
		}
		boolean isValidDate(String date, String prev){
			return super.isValidDate(1, date, prev);
		}
		String getDate(int status){ //same as Option1 getDate
			if(status == 0 ){
				System.out.println("What is the first day of the period (YYMMDD) that you would like to use?");
				String startDate = getLine();
				while(!isValidDate(startDate, null)){
					System.out.print("Please enter a valid date(YYMMDD): ");
					startDate=getLine();
				}
				return startDate;
			}
			if(status == 1){
				System.out.println("What is the last day of the period (YYMMDD) that you would like to use?");
				String endDate = getLine();
				while(!isValidDate(endDate, startDate)){
					System.out.print("Please enter a valid date(YYMMDD): ");
					endDate=getLine();
				}
				return endDate;
			}
			return null;
		}
		void writeToFile() throws IOException{ //create the new file
			int switcherSixes = 1; //balancer for sixes
			FileWriter fstream = new FileWriter(newfile);
			BufferedWriter out = new BufferedWriter(fstream);
			try {
				File file = new File("C:/Master Scripts/ARAdjustments.mac"); 
				Scanner scanner = new Scanner(file);
				String newLine = "";
				while (scanner.hasNextLine()) {
					newLine = scanner.nextLine(); 
						if (newLine.contains("YYMMDD")) {
									if (switcherSixes > 0) { 
										newLine=newLine.replace("YYMMDD", startDate); 
									}
									else { 
										newLine=newLine.replace("YYMMDD", endDate);
									}
									switcherSixes = -switcherSixes;
								}
						out.write(newLine); 
						out.newLine();
				}
				scanner.close(); //close the scanner to prevent leaking
				System.out.println("File created successfully.");
			}
			catch (FileNotFoundException e) {
				System.out.println("Invalid reference given."); //reference file does not exist
				return; 
			}
			finally{
				out.close();
			}
		}
		void execute() throws IOException{ //run all methods and finish 
			promptForFileName();
			startDate= getDate(0);
			endDate = getDate(1);
			writeToFile();
		}
	}
	static void OptionPrompt() throws IOException{ //startup and call the correct option
		Scanner scanner = new Scanner(System.in);
		System.out.println("Script Editor Version 3.2.1");
		System.out.println("Created by QStwo LLC");
		System.out.println("What type of script file do you want to edit?\n(1) GL_Activity\n(2) AP_Posting\n(3) Trial_Balance\n(4) AP_to_GL_wrkqry\n(5) ARCASH12\n(6) CCINV\n(7) ARAdjustment");//FIFTH TITLE MUST BE CHANGED
		System.out.print("Enter a number: ");
		String response = scanner.nextLine();
		boolean flag=true;
		while(flag){
			try{
				int numVer = Integer.parseInt(response);
				if(numVer > 7 || numVer <= 0){
					if(numVer == 0)
						System.out.print("Please enter a valid number (1-7)[input was 0]: ");		
					else
						System.out.print("Please enter a valid number (1-7)[input was greater than 7 or negative]: ");
					response = scanner.nextLine();
				}
				else{
					flag = false;
					if(numVer==1)
						new Option1().execute(); //user indicated option 1
					if(numVer==2)
						new Option2().execute(); //user indicated option 2
					if(numVer==3)
						new Option3().execute(); //user indicated option 3
					if(numVer==4)
						new Option4().execute(); //user indicated option 4
					if(numVer==5)
						new Option5().execute(); //user indicated option 5
					if(numVer==6)
						new Option6().execute(); //user indicated option 6
					if(numVer==7)
						new Option7().execute();
					//scanner.close();
					//return;
				}
			}
			catch(NumberFormatException e){ //if input was not a number
				System.out.print("Please enter a valid number(1-7) [input was not a number]: ");
				response = scanner.nextLine();
			}
		}
		System.out.println("Please type 0 to restart this program or 1 to exit the program.");
		String response2  = scanner.nextLine();
		while(!(response2.equals("0")||response2.equals("1")))
			System.out.println("Please type 0 or 1.");
			if(response2.equals("1"))
				System.exit(0);
			else
				OptionPrompt();
		scanner.close();
	}
	public static void main(String[] args) throws IOException{
			OptionPrompt(); //run the prompt
	}
}